ArmyTransferSendUnit = {
    '单位名称': '一汽(四川)专用汽车有限公司',
    '联系人': '杨伟',
    '联系电话': '13880585552'
}

ArmyTransferReceiveUnit = {
    '单位名称': '火箭军',
    '联系人': '',
    '联系电话': ''
}

#new